<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Box</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="content-wrap">
        <header>
            <div class="container">
                <h1 class="text-left">Taksofonas</h1>
                <nav>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                    </ul>
                </nav> 
            </div>
        </header>
        <div class="about-background">
            <!-- Existing taksofonas photo -->
        </div>
        <div class="callme-background">
            <!-- New callMeMaybe photo -->
            <p class="photo-text">Team Call Me Maybe</p> <!-- Text for the callMeMaybe photo -->
        </div>
        <main>
            <div class="container">
                <h2></h2>
            </div>
        </main>
    </div>
</body>
</html>