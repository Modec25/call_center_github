<?php

require_once '/var/www/html/call-center/vendor/autoload.php';

use Twilio\Rest\Client;

$accountSid = "AC62b9b7ebda7748c284562396f4ef7335";
$authToken = "42cb7470d9508abf0cef2abf3d4b2f96";

$twilio = new Client($accountSid, $authToken);

$toPhoneNumber = $_POST['phoneNumber'];

// Validate and format the phone number
$toPhoneNumber = validateAndFormatPhoneNumber($toPhoneNumber);

// Make the call
$call = $twilio->calls
    ->create(
        $toPhoneNumber,
        "+18052840465",
        ["url" => "https://demo.twilio.com/docs/voice.xml"]
    );

echo $call->sid;

// Function to validate and format the phone number
function validateAndFormatPhoneNumber($phoneNumber)
{
    if (strpos($phoneNumber, '+') !== 0) {
        // If the phone number does not start with '+', add it
        $phoneNumber = '+' . $phoneNumber;
    }

    // Remove non-numeric characters
    $phoneNumber = preg_replace('/[^\d]/', '', $phoneNumber);

    return $phoneNumber;
}

?>